# API Sample - NodeJS
Contains several API calls samples for App Owns Data.

After registering an app, Fill config parameters under config.json.

Use one of the methods in **powerbi-api-calls-sample.js** to make the coresponding api call.

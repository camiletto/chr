# Source code for integrate a report / dashboard / tile into an app walkthrough
Integrate a Power BI element enables application developers to integrate Power BI elements from a user's power BI account by embedding an IFrame into an app, such as a mobile app or web app.

See [Integrate a report into an app walkthrough](https://powerbi.microsoft.com/en-us/documentation/powerbi-developer-integrate-report).
